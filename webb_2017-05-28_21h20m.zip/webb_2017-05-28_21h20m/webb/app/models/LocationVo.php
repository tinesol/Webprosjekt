<?php

namespace Webb\App\Models;

class LocationVo extends Vo
{
    protected $id;
    protected $address;
    protected $zipCode;
    protected $city;
    protected $locationPath;

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setAddress($address)
    {
        $this->address = $address;
    }

    public function getAddress()
    {
        return $this->address;
    }

    public function setZipCode($zipCode)
    {
        $this->zipCode = $zipCode;
    }

    public function getZipCode()
    {
        return $this->zipCode;
    }

    public function setCity($city)
    {
        $this->city = $city;
    }

    public function getCity()
    {
        return $this->city;
    }

    public function setLocationPath($locationPath)
    {
        $this->locationPath = $locationPath;
    }

    public function getLocationPath()
    {
        return $this->locationPath;
    }

}
